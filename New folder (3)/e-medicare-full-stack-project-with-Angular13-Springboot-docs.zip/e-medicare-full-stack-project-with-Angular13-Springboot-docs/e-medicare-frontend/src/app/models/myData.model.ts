export interface myData {
    u_id:number;
    dob: string;
    email: string;
    firstname: string;
    lastname: string;
    password: string;
    gender:string;
    contact_no: string;
  }
  