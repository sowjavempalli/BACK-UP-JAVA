export interface Authentication {
    username: string;
    password: string;
    authenticated: boolean;
  }