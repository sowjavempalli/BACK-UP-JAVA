export class Cart{
    
    id:number=0;
    quantity:number=1;
    itemId:number=0;
    
}