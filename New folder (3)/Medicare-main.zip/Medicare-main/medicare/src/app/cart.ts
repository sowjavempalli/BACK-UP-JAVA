import { Product } from './product';
import { User } from './user';

export class Cart {
    id:number;
    product:Product;
    user:User;
}
